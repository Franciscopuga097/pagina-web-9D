<footer>
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <h4 class="text-info">Siguenos</h4>
        <a href="#" class="text-warning"><i class="fa fa-facebook" aria-hidden="true"></i> &nbsp; Facebook</a><br>
        <a href="#" class="text-warning"><i class="fa fa-twitter" aria-hidden="true"></i> &nbsp; Twitter</a><br>
        <a href="#" class="text-warning"><i class="fa fa-youtube-play" aria-hidden="true"></i> &nbsp; YouTube</a><br>
        <a href="#" class="text-warning"><i class="fa fa-instagram" aria-hidden="true"></i> &nbsp; Instagram</a>
      </div>
      <div class="col-sm-4">
        <h4 class="text-info">Dirección</h4>
        <p class="text-warning"> 
        Pais: Mexico<br>
        Ciudad: Santa Catarina<br>
        Telefono: +00000000000<br>
        E-mail: <a href="#">Pugatech@utsc.com</a>
        </p>
      </div>
        </form>
      </div>
    </div>
    <h4 class="text-center" style="color: #FFF;">15443 CopyRight © 2022</h4>
  </div>
</footer>